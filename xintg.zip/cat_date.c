// $Id: cat_date.c 54124 2011-04-27 17:36:54Z Janet.Irwin $

// includes --------------------------------------------------------------------
#include <string.h>
#include <time.h>

//------------------------------------------------------------------------------
// Function: cat_date()
// Description:
//    Adds date to end of prefix, returns result cname 
//    Date format = CCYYMMDD.hhmmss
//------------------------------------------------------------------------------
void cat_date(
   char *prefix, 
   char *cname
) 
{

   time_t now;
   char date_time[16];

   now = time(NULL);
   strncpy(date_time, "\0", 16);
   strftime(date_time, 16, "%y%m%d.%X", localtime(&now));

   strcpy(cname, prefix);
   strcat(cname, date_time);

} // end cat_date()

