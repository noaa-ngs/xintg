//This code is copied from HTDP - fortran converted to c.
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>
#include <math.h>      // sqrt()
#include "boundary.h"

#define L_LENGTH 127

int POLYIN(double X0, double Y0, double X[], double Y[], int N);

//-------------------------------------------------------------------------------------------------

int am_I_on_the_Pacific_plate(double fi, double la) {

    //  Given your latitude and longitude, this little routine tells you if you are on
    //  the Pacific tectonic.                 

    //  "Pacific.gmt", is an ASCII file that contains the coordinates of the boundary polygon of the Pacific plate.             
    //  This polygon is closed (starts and ends at the same point). File format: (East) longitude and latitude in decimal degrees.


    int i, NPC, num;
    char line[L_LENGTH];

    //  Constants

    num = 1219;


    double X1[num], Y1[num]; //I am not sure the cheap compilers in subversion can handle dynamic memory;

    //  Read and store the coordinates of the Pacific boundary polygon
    strncpy(line, "\0", L_LENGTH);
    char tmpLat[16];
    char tmpLon[16];
    i = 0;    
    for (i = 0; i < 1219; i++){
        strncpy(tmpLat, boundaries[i], 10);
        strncpy(tmpLon, boundaries[i]+10, 15);       
        X1[i] = atof (tmpLat);
        Y1[i] = atof (tmpLon);        
    }

    //  Do your coordinates fall inside the Pacific plate
    //  If yes then NPC will return as 1 or 2

    NPC = POLYIN(la, fi, X1, Y1, num);

    //  Test 

    if ((NPC == 1) || (NPC == 2)) {
        return 1;
    }

    return 0;
};




//---------------------------------------------------------------------------------------------------------------------
// --------------------------------------------
int POLYIN(double X0, double Y0, double X[], double Y[], int N)
{
    //     SUBROUTINE TO DETERMINE IF A POINT AT (X0,Y0) IS INSIDE OR
    //     OUTSIDE OF A CLOSED FIGURE DESCRIBED BY A SEQUENCE OF CONNECTED
    //     STRAIGHT LINE SEGMENTS WITH VERTICES AT X, Y.
    //
    //     INPUT -
    //         X0, Y0    COORDINATES OF A POINT TO BE TESTED
    //                    Y0 corresponds to longitude and must be a number
    //                    between 0.0 and 2*PI
    //         X, Y      ARRAYS CONTAINING THE VERTICES, IN ORDER, OF A
    //                   CLOSED FIGURE DESCRIBED BY STRAIGHT LINE SEGMNENTS.
    //                   FOR EACH 'I', THE STRAIGHT LINE FROM (XI),Y(I)) TO
    //                   TO (X(I+1),Y(I+1)), IS AN EDGE OF THE FIGURE.
    //         N         DIMENSION OF X AND Y, NUMBER OF VERTICES, AND NUMBER
    //                   OF STRAIGHT LINE SEGMENTS IN FIGURE.
    //     OUTPUT -
    //         NPC       NPC=0 WHEN X0,Y0 IS OUTSIDE OF FIGURE DESCRIBED
    //                   BY X,Y
    //                   NPC=1 WHEN X0,Y0 IS INSIDE FIGURE
    //                   NPC=2 WHEN X0,Y0 IS ON BORDER OF FIGURE
    //     METHOD -
    //     A COUNT IS MADE OF THE NUMBER OF TIMES THE LINE FROM (X0,Y0) TO
    //     (X0,+ INFINITY) CROSSES THE BORDER OF THE FIGURE. IF THE COUNT
    //     IS ODD, THE POINT IS INSIDE; IF THE COUNT IS EVEN THE POINT
    //     IS OUTSIDE.
    //     LIMITATIONS -
    //     NONE. THE PROGRAM LOGIC IS VALID FOR ALL CLOSED FIGURES,
    //     NO MATTER HOW COMPLEX.
    //     ACCURACY -
    //     MAINTAINS FULL ACCURACY OF INPUT COORDINATES.
    //
    // implicit int*4(I - N)
    // implicit double(A - H, O - Z)
    //DIMENSION X(N), Y(N)
    //DATA I6/6/;
    int IS = 0;
    int NPC = 0;
    int IL, XL, YL;
    //
    //     FIND STARTING POINT WHERE X(I).NE.X0
    int IP = 0;
g10:
    IP = IP + 1;
    if ((X[IP] - X0) < 0){
        goto g15;
    }else if ((X[IP] - X0) == 0){
        goto g12;
    }else {
        goto g16;
    }
        
g12:
    if (IP <= N) goto g10;
    printf("'0  POLYGON INPUT ERROR - ALL POINTS ON LINE X = X0'");  
    
    exit(0);
g15:
    IL = -1;
    goto g20;
g16:
    IL = 1;
g20:
    XL = X[IP];
    YL = Y[IP];
    //
    //     SET UP SEARCH LOOP
    //
    int IP1 = IP + 1;
    int IPN = IP + N;
    int II;
    int I;
    for(II=IP1; II<=IPN; II++)
    {
        I = II;
        if (I > N) I = I - N;
        if (IL < 0){
            goto g30;
        }else if (IL == 0){
            goto g50;
        }else{
            goto g40;
        }
            
g30:
        if ((X[I] - X0) < 0){
            goto g90;
        }else if ((X[I] - X0) == 0){
            goto g32;
        }else{
            goto g34;
        }
            
g32:
        IS = -1;
        goto g60;
g34:
        IL = 1;
        goto g80;
g40:
        if ((X[I] - X0) < 0){
            goto g42;
        }else if ((X[I] - X0) == 0){
            goto g44;
        }else{
            goto g90;
        }
            
g42:
        IL = -1;
        goto g80;
g44:
        IS = 1;
        goto g60;
g50:
        if ((X[I] - X0) < 0){
            goto g52;
        }else if ((X[I] - X0) == 0){
            goto g55;
        }else{
            goto g54;
        }
            
g52:
        IL = -1;
        if (IS < 0){
            goto g90;
        }else if (IS == 0){
            goto g140;
        }else{
            goto g80;
        }
            
g54:
        IL = 1;
        if (IS < 0){
            goto g80;
        }else if (IS == 0){
            goto g140;
        }else{
            goto g90;
        }
            
g55:
        if ((Y[I] - Y0) < 0){
            goto g57;
        }else if ((Y[I] - Y0) == 0){
            goto g120;
        }else{
            goto g58;
        }
            
g57:
        if ((YL - Y0) < 0){
            goto g90;
        }else if ((YL - Y0) == 0){
            goto g120;
        }else{
            goto g120;
        }
            
            
g58:
        if ((YL - Y0) < 0){
            goto g120;
        }else if ((YL - Y0) == 0){
            goto g120;
        }else{
            goto g90;
        }
            
        //
g60:
        IL = 0;
        if ((Y[I] - Y0) < 0){
            goto g90;
        }else if ((Y[I] - Y0) == 0){
            goto g120;
        }else{
            goto g90;
        }
            
g80:
        if ((YL - Y0 + (Y[I] - YL)*(X0 - XL)/(X[I] - XL)) < 0){
            goto g90;
        }else if ((YL - Y0 + (Y[I] - YL)*(X0 - XL)/(X[I] - XL)) == 0){
            goto g120;
        }else{
            goto g85;
        }
            
g85:
        NPC = NPC + 1;
g90:
        XL = X[I];
        YL = Y[I];
        
    }
    return NPC % 2;
g120:
    NPC = 2;
    return 2;
g140:
    printf("0  POLYGON LOGIC ERROR - PROGRAM SHOULD NOT REACH THIS POINT");  
    
    return 0;
};