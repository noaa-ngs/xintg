#ifndef FLIP_ENDIAN_L_H
#define FLIP_ENDIAN_L_H

// %P%
// ----- constants ---------------------------------------------------
#pragma ident "$Id: flip_endian_l.h 35293 2010-06-11 13:16:40Z Srinivas.Reddy $	20$Date: 2009/05/15 14:00:06 $ NGS"

// ----- standard library --------------------------------------------
// ----- classes, structs, types -------------------------------------
// ----- functions ---------------------------------------------------
long flip_endian_l( long ll );

#endif //~FLIP_ENDIAN_L_H

