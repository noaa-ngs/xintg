#ifndef DD_DMS_H
#define DD_DMS_H

// %P%
#pragma ident "$Id: dd_dms.h 35289 2010-06-11 13:16:23Z Srinivas.Reddy $ NGS"

// ----- local functions ---------------------------------------------
char* dd_dms( double dd, char* answer );

#endif //~DD_DMS_H 
