#ifndef FLIP_ENDIAN_F_H
#define FLIP_ENDIAN_F_H

// %P%
// ----- constants ---------------------------------------------------
#pragma ident "$Id: flip_endian_f.h 35292 2010-06-11 13:16:35Z Srinivas.Reddy $	20$Date: 2009/05/15 13:59:58 $ NGS"

// ----- standard library --------------------------------------------
// ----- classes, structs, types -------------------------------------
// ----- functions ---------------------------------------------------
float flip_endian_f( float ff );

#endif //~FLIP_ENDIAN_F_H

