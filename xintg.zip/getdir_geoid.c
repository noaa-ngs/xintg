// %P%
// ----- constants ---------------------------------------------------
static const char SCCSID[]="$Id: getdir_geoidux.c 35346 2010-06-11 13:30:25Z Srinivas.Reddy $	20$Date: 2010/02/22 09:39:37 $ NGS";

// ----- standard library --------------------------------------------
#include <stdio.h>
#include <string.h>

// ----- classes, structs, types -------------------------------------
// ----- functions ---------------------------------------------------
#include "getdir_geoid.h"
extern int isFirstRun;
extern char pcDir[255];


int getdir_geoid(int imodel, char* dirnam) {
#ifdef NGS_PC_ENV
   /*******************************************************************************
    * For PC network system, returns the directory location
    * where geoid binary model grid files are located.
    *  in - imodel : user selected geoid model   int
    *  in - dirnam : char vector, empty          character*256
    *  out- dirnam : char vector, filled
    *******************************************************************************/

    if (isFirstRun){
	isFirstRun = 0;
	strncpy(dirnam, "\0", 256);
	strncpy(pcDir, "\0", 255);

	printf("\n\
	  What is the **FULL** directory name (including trailing slashes) \n\
	  where the geoid (*.bin) files may be found? \n\
	 (Example:  C:\\GEOID\\) \n\
	 Hit <RETURN> to default to this directory \n\
	 -> ");

	fgets(dirnam, 256, stdin);
	if (strlen(dirnam) > 0){
            dirnam[strlen(dirnam) - 1] = '\0';
    	}

    	strcpy(pcDir, dirnam);
    }else{
        strncpy(dirnam, "\0", 256);
        strcpy(dirnam, pcDir);
    }

    switch (imodel) {
    case 12:
        strcat(dirnam, "Geoid12B\\");
        break;
    case 13:
        strcat(dirnam, "USGG2012\\");
        break;
    case 14:
        strcat(dirnam, "xGeoid14A\\");
        break;
    case 15:
        strcat(dirnam, "xGeoid14B\\");
        break;
    case 16:
        strcat(dirnam, "xGeoid15A\\");
        break;
    case 17:
        strcat(dirnam, "xGeoid15B\\");
        break;
    case 18:
        strcat(dirnam, "xGeoid16A\\");
        break;
    case 19:
        strcat(dirnam, "xGeoid16B\\");
        break;
    case 20:
        strcat(dirnam, "xGeoid17A\\");
        break;
    case 21:
        strcat(dirnam, "xGeoid17B\\");
        break;
    case 22:
        strcat(dirnam, "xGeoid18A\\");
        break;
    case 23:
        strcat(dirnam, "xGeoid18B\\");
        break;
    case 24:
        strcat(dirnam, "xGeoid19A\\");
        break;
    case 25:
        strcat(dirnam, "xGeoid19B\\");
        break;

    default:
        fprintf(stderr, "ERROR: in file getdirux, invalid option %d\n", imodel);
        return( -1 );
    }//~switch    

#else
   /*******************************************************************************
    * For the NGS unix network system, returns the directory location
    * where geoid binary model grid files are located.
    *  in - imodel : user selected geoid model   int
    *  in - dirnam : char vector, empty          character*256 dirnam
    *  out- dirnam : char vector, filled
    *******************************************************************************/
    switch (imodel) {
    case 12:
        strcpy(dirnam, "/ngslib/data/Geoid/Geoid12B/");
        break;
    case 13:
        strcpy(dirnam, "/ngslib/data/Geoid/USGG2012/");
        break;
    case 14:
        strcpy(dirnam, "/ngslib/data/Geoid/xGeoid14A/");
        break;
    case 15:
        strcpy(dirnam, "/ngslib/data/Geoid/xGeoid14B/");
        break;
    case 16:
        strcpy(dirnam, "/ngslib/data/Geoid/xGeoid15A/");
        break;
    case 17:
        strcpy(dirnam, "/ngslib/data/Geoid/xGeoid15B/");
        break;
    case 18:
        strcpy(dirnam, "/ngslib/data/Geoid/xGeoid16A/");
        break;
    case 19:
        strcpy(dirnam, "/ngslib/data/Geoid/xGeoid16B/");
        break;
    case 20:
        strcpy(dirnam, "/ngslib/data/Geoid/xGeoid17A/");
        break;
    case 21:
        strcpy(dirnam, "/ngslib/data/Geoid/xGeoid17B/");
        break;
    case 22:
        strcpy(dirnam, "/ngslib/data/Geoid/xGeoid18A/");
        break;
    case 23:
        //strcpy(dirnam, "/tmp/");
        strcpy(dirnam, "/ngslib/data/Geoid/xGeoid18B/");
        break;
    case 24:
        strcpy(dirnam, "/ngslib/data/Geoid/xGeoid19A/");
        break;
    case 25:
        strcpy(dirnam, "/ngslib/data/Geoid/xGeoid19B/");
        break;

    default:
        fprintf(stderr, "ERROR: in file getdirux, invalid option %d\n", imodel);
        return( -1 );
    }//~switch

#endif

    return(0);

}//~getdir_geoid

