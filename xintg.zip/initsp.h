#ifndef INITSP_H
#define INITSP_H

// %P%
// ----- constants ---------------------------------------------------
#pragma ident "$Id: initsp.h 35295 2010-06-11 13:16:49Z Srinivas.Reddy $	20$Date: 2009/05/15 14:00:20 $ NGS"

// ----- standard library --------------------------------------------
// ----- classes, structs, types -------------------------------------
// ----- functions ---------------------------------------------------
void initsp(double* YY, long nn, double* RR, double* QQ);


#endif //~INITSP_H

