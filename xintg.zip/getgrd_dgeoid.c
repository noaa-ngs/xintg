// %P%
// ----- constants ---------------------------------------------------
// $Rev:: 6#$
// $Date::  $
// $Id:: ge#$

// ----- standard library --------------------------------------------
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// ----- classes, structures, types ----------------------------------
// ----- functions ---------------------------------------------------
#include "getgrd_dgeoid.h"
#include "trim_c.h"


void getgrd_dgeoid(int imodel, char* dirnam, int is_subr, int* nfiles, int* nff,
                  char vec_fnames[1][256], FILE* vec_ifp[1][50], int count) {
/*******************************************************************************
* "get (Dgeoid) grids"
* Fills a vector with the file names of the gridded input data,
* and open all files that can be found in the given directory.
* Additional geoid models may be added as developed.
*  in - imodel  : integer key to specific geoid model
*  in - dirnam  : directory location of binary geoid model files
*               : special- "ngs" is key to use NGS network files
*  in - IS_SUBR : run as subroutine: false=0;  true=1; (c std notation)
*  out- nfiles  : number of binary files used for the specific geoid model
*  out- fnam    : array (vector of character vectors) of geoid model filenames
*  out- lin     : vector of file unit numbers  (type = long int)
*               : of geoid model files opened in this subroutine
*  out- nff     : "Number of Files Found" and --successfully opened--
*
* Notes:
* was: (imodel, dirnam, is_subr, nfiles, fnam, lin, nff )
*      int* imodel; char* dirnam; int*  is_subr; int*  nfiles;
*      char* fnam;   int*  lin;   int*  nff;
*******************************************************************************/
    char  this_fname[256];
    char  cval[3];
    const char suffix[] = ".bin";
    int numVecFiles = 0;

    int  dirlen = 0;
    int  ii;

    *nff = 0;

    trim_c(dirnam, 'b');
    dirlen = strlen(dirnam);
    // -----------------------------------------------------
    // Open 
    // -----------------------------------------------------
    if (imodel >= 24 && imodel <= 25) {
        *nfiles = 3;

        // Attempt to open the one file model
        FILE* ifp_conus;
        FILE* ifp_as;
        FILE* ifp_gu;
        strncpy(this_fname, "\0", 256);
        if (dirlen > 0) {
            strcpy(this_fname, dirnam);
        }

        strcat(this_fname, "xDGEOID19.bin");

        if ((ifp_conus = fopen(this_fname, "rb")) != NULL) {
            strcpy(vec_fnames[numVecFiles++], this_fname);
            fclose(ifp_conus);

        }

        strcpy(this_fname, dirnam);
        strcat(this_fname, "xDGEOID19_AS.bin");

        if ((ifp_as = fopen(this_fname, "rb")) != NULL) {
            strcpy(vec_fnames[numVecFiles++], this_fname);
            fclose(ifp_as);

        }

        strcpy(this_fname, dirnam);
        strcat(this_fname, "xDGEOID19_GU.bin");

        if ((ifp_gu = fopen(this_fname, "rb")) != NULL) {
            strcpy(vec_fnames[numVecFiles++], this_fname);
            fclose(ifp_gu);

        }


    } //~if(imodel)
    
    // -----------------------------------------------------
    // Open all the files that were found
    // Iterate thru the Filenames vector
    // Open files, store ifstreams to ifstream vector
    // Grid file format is unformatted, direct access
    // -----------------------------------------------------
    *nfiles = numVecFiles;
    for (ii = 0; ii < *nfiles; ++ii) {
        FILE* ifp;
        ifp = fopen(vec_fnames[ii], "rb");
        vec_ifp[count][ii] = ifp;             // Store FILE, success -or- fail (NULL)

        if( (ifp == NULL) && (is_subr == 0) ) {
            printf("Open file failed for %s\n", vec_fnames[ii]);
        }

        if (ifp != NULL) {
            ++(*nff);
/*
            if (is_subr == 0) {   // (0 := false)
                fprintf(stdout, " *** Opening File: %s\n", vec_fnames[ii]);
            }
*/
        }
    }

    // -----------------------------------------------------
    // Check and see if at least ONE file was opened,
    // and make a count of how many WERE opened.
    // Abort if we find no geoid files.
    // -----------------------------------------------------
    if (*nff == 0) {
        fprintf(stderr, "\
ERROR(299):  No files found -- aborting \n\
    Input directory  = %s \n\
    Input model code = %d \n", dirnam, imodel);
        abort();
    }

    return;

}//~getgrd_geoid

