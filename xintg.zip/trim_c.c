// $Id: trim_c.c 77681 2014-06-12 15:13:12Z zedong.zhang $

// ----- standard library ------------------------------------------------------
#include <ctype.h>
#include <malloc.h>
#include <string.h>

//------------------------------------------------------------------------------
// Removes leading and/or trailing white space chars from the input string.
// --- NON - STDC++ version ---
// Parameters:
//  in -  str : ptr to char string to be trimmed.
//  in -  w   : where to trim: left='L'or'l'; right='R'or'r'; --no default--
//  out-  str : ptr to the trimmed char string     by reference
//  ret-      : ptr to the trimmed char string
//------------------------------------------------------------------------------
char *trim_c(
   char *str, 
   const char w
) 
{

    int ii=0;
    char *ptr;
    char str2[80];


    // Trim on the left
    if ( strchr("LlBb", w) ) {
       for (ii = 0; ii<= strlen(str); ++ii) {
          if (!isspace(str[ii])) break;
       }
       if(ii > 0) {
	  strcpy(str2, str+ii);
          strcpy(str, str2);
       }
    }

    // Trim on the right
    if (strchr("RrBb", w) != 0) {
       for (ii = (strlen(str)-1); (ii >= 0 && isspace(str[ii]) != 0); --ii) {
          str[ii] = '\0';
       }
    }

    return(str); // Return the trimmed string

} // trim_c()
